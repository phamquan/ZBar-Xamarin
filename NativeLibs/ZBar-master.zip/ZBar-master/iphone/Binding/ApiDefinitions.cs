using System;
using CoreGraphics;
using Foundation;
using ObjCRuntime;
using UIKit;

// @interface ZBarSymbolSet : NSObject <NSFastEnumeration>
[BaseType (typeof(NSObject))]
interface ZBarSymbolSet : INSFastEnumeration
{
	// @property (readonly, nonatomic) int count;
	[Export ("count")]
	int Count { }

	// @property (readonly, nonatomic) const int * zbarSymbolSet;
	[Export ("zbarSymbolSet")]
	unsafe int* ZbarSymbolSet { }

	// @property (nonatomic) BOOL filterSymbols;
	[Export ("filterSymbols")]
	bool FilterSymbols { }

	// -(id)initWithSymbolSet:(id)set;
	[Export ("initWithSymbolSet:")]
	IntPtr Constructor (NSObject set);

	// -(NSArray *)toArray;
	[Export ("toArray")]
	[Verify (MethodToProperty), Verify (StronglyTypedNSArray)]
	NSObject[] ToArray { get; }
}

// @interface ZBarSymbol : NSObject
[BaseType (typeof(NSObject))]
interface ZBarSymbol
{
	// @property (readonly, nonatomic) int type;
	[Export ("type")]
	int Type { }

	// @property (readonly, nonatomic) NSString * typeName;
	[Export ("typeName")]
	string TypeName { }

	// @property (readonly, nonatomic) NSUInteger configMask;
	[Export ("configMask")]
	nuint ConfigMask { }

	// @property (readonly, nonatomic) NSUInteger modifierMask;
	[Export ("modifierMask")]
	nuint ModifierMask { }

	// @property (readonly, nonatomic) NSString * data;
	[Export ("data")]
	string Data { }

	// @property (readonly, nonatomic) int quality;
	[Export ("quality")]
	int Quality { }

	// @property (readonly, nonatomic) int count;
	[Export ("count")]
	int Count { }

	// @property (readonly, nonatomic) int orientation;
	[Export ("orientation")]
	int Orientation { }

	// @property (readonly, nonatomic) ZBarSymbolSet * components;
	[Export ("components")]
	ZBarSymbolSet Components { }

	// @property (readonly, nonatomic) const int * zbarSymbol;
	[Export ("zbarSymbol")]
	unsafe int* ZbarSymbol { }

	// @property (readonly, nonatomic) CGRect bounds;
	[Export ("bounds")]
	CGRect Bounds { }

	// -(id)initWithSymbol:(id)symbol;
	[Export ("initWithSymbol:")]
	IntPtr Constructor (NSObject symbol);

	// +(NSString *)nameForType:(id)type;
	[Static]
	[Export ("nameForType:")]
	string NameForType (NSObject type);
}

// @interface ZBarImage : NSObject
[BaseType (typeof(NSObject))]
interface ZBarImage
{
	// @property (nonatomic) unsigned long format;
	[Export ("format")]
	nuint Format { }

	// @property (nonatomic) unsigned int sequence;
	[Export ("sequence")]
	uint Sequence { }

	// @property (nonatomic) CGSize size;
	[Export ("size", ArgumentSemantic.Assign)]
	CGSize Size { }

	// @property (nonatomic) CGRect crop;
	[Export ("crop", ArgumentSemantic.Assign)]
	CGRect Crop { }

	// @property (readonly, nonatomic) const void * data;
	[Export ("data")]
	unsafe void* Data { }

	// @property (readonly, nonatomic) unsigned long dataLength;
	[Export ("dataLength")]
	nuint DataLength { }

	// @property (copy, nonatomic) ZBarSymbolSet * symbols;
	[Export ("symbols", ArgumentSemantic.Copy)]
	ZBarSymbolSet Symbols { }

	// @property (readonly, nonatomic) int * zbarImage;
	[Export ("zbarImage")]
	unsafe int* ZbarImage { }

	// @property (readonly, nonatomic) UIImage * UIImage;
	[Export ("UIImage")]
	UIImage UIImage { }

	// -(id)initWithImage:(id)image;
	[Export ("initWithImage:")]
	IntPtr Constructor (NSObject image);

	// -(id)initWithCGImage:(CGImageRef)image;
	[Export ("initWithCGImage:")]
	unsafe IntPtr Constructor (CGImageRef* image);

	// -(id)initWithCGImage:(CGImageRef)image size:(CGSize)size;
	[Export ("initWithCGImage:size:")]
	unsafe IntPtr Constructor (CGImageRef* image, CGSize size);

	// -(id)initWithCGImage:(CGImageRef)image crop:(CGRect)crop size:(CGSize)size;
	[Export ("initWithCGImage:crop:size:")]
	unsafe IntPtr Constructor (CGImageRef* image, CGRect crop, CGSize size);

	// -(void)setData:(const void *)data withLength:(unsigned long)length;
	[Export ("setData:withLength:")]
	unsafe void SetData (void* data, nuint length);

	// -(UIImage *)UIImageWithOrientation:(UIImageOrientation)imageOrientation;
	[Export ("UIImageWithOrientation:")]
	UIImage UIImageWithOrientation (UIImageOrientation imageOrientation);

	// -(void)cleanup;
	[Export ("cleanup")]
	void Cleanup ();

	// +(unsigned long)fourcc:(NSString *)format;
	[Static]
	[Export ("fourcc:")]
	nuint Fourcc (string format);
}

// @interface ZBarImageScanner : NSObject
[BaseType (typeof(NSObject))]
interface ZBarImageScanner
{
	// @property (nonatomic) BOOL enableCache;
	[Export ("enableCache")]
	bool EnableCache { }

	// @property (readonly, nonatomic) ZBarSymbolSet * results;
	[Export ("results")]
	ZBarSymbolSet Results { }

	// -(void)parseConfig:(NSString *)configStr;
	[Export ("parseConfig:")]
	void ParseConfig (string configStr);

	// -(void)setSymbology:(id)symbology config:(id)config to:(int)value;
	[Export ("setSymbology:config:to:")]
	void SetSymbology (NSObject symbology, NSObject config, int value);

	// -(NSInteger)scanImage:(ZBarImage *)image;
	[Export ("scanImage:")]
	nint ScanImage (ZBarImage image);
}

// @protocol ZBarReaderDelegate <UIImagePickerControllerDelegate>
[Protocol, Model]
interface ZBarReaderDelegate : IUIImagePickerControllerDelegate
{
	// @optional -(void)readerControllerDidFailToRead:(ZBarReaderController *)reader withRetry:(BOOL)retry;
	[Export ("readerControllerDidFailToRead:withRetry:")]
	void WithRetry (ZBarReaderController reader, bool retry);
}

// @interface ZBarReaderController : UIImagePickerController <UINavigationControllerDelegate, UIImagePickerControllerDelegate>
[BaseType (typeof(UIImagePickerController))]
interface ZBarReaderController : IUINavigationControllerDelegate, IUIImagePickerControllerDelegate
{
	// @property (readonly, nonatomic) ZBarImageScanner * scanner;
	[Export ("scanner")]
	ZBarImageScanner Scanner { get; }

	[Wrap ("WeakReaderDelegate")]
	ZBarReaderDelegate ReaderDelegate { get; set; }

	// @property (assign, nonatomic) id<ZBarReaderDelegate> readerDelegate;
	[NullAllowed, Export ("readerDelegate", ArgumentSemantic.Assign)]
	NSObject WeakReaderDelegate { get; set; }

	// @property (nonatomic) BOOL showsZBarControls;
	[Export ("showsZBarControls")]
	bool ShowsZBarControls { get; set; }

	// @property (nonatomic) BOOL showsHelpOnFail;
	[Export ("showsHelpOnFail")]
	bool ShowsHelpOnFail { get; set; }

	// @property (nonatomic) ZBarReaderControllerCameraMode cameraMode;
	[Export ("cameraMode", ArgumentSemantic.Assign)]
	ZBarReaderControllerCameraMode CameraMode { get; set; }

	// @property (nonatomic) BOOL tracksSymbols;
	[Export ("tracksSymbols")]
	bool TracksSymbols { get; set; }

	// @property (nonatomic) BOOL takesPicture;
	[Export ("takesPicture")]
	bool TakesPicture { get; set; }

	// @property (nonatomic) BOOL enableCache;
	[Export ("enableCache")]
	bool EnableCache { get; set; }

	// @property (nonatomic) CGRect scanCrop;
	[Export ("scanCrop", ArgumentSemantic.Assign)]
	CGRect ScanCrop { get; set; }

	// @property (nonatomic) NSInteger maxScanDimension;
	[Export ("maxScanDimension")]
	nint MaxScanDimension { get; set; }

	// -(void)showHelpWithReason:(NSString *)reason;
	[Export ("showHelpWithReason:")]
	void ShowHelpWithReason (string reason);

	// -(id<NSFastEnumeration>)scanImage:(CGImageRef)image;
	[Export ("scanImage:")]
	unsafe NSFastEnumeration ScanImage (CGImageRef* image);
}

[Static]
[Verify (ConstantsInterfaceAssociation)]
partial interface Constants
{
	// extern NSString *const ZBarReaderControllerResults;
	[Field ("ZBarReaderControllerResults", "__Internal")]
	NSString ZBarReaderControllerResults { get; }
}

// @interface ZBarReaderViewController : UIViewController
[BaseType (typeof(UIViewController))]
interface ZBarReaderViewController
{
	// @property (readonly, nonatomic) ZBarImageScanner * scanner;
	[Export ("scanner")]
	ZBarImageScanner Scanner { get; }

	[Wrap ("WeakReaderDelegate")]
	ZBarReaderDelegate ReaderDelegate { get; set; }

	// @property (assign, nonatomic) id<ZBarReaderDelegate> readerDelegate;
	[NullAllowed, Export ("readerDelegate", ArgumentSemantic.Assign)]
	NSObject WeakReaderDelegate { get; set; }

	// @property (nonatomic) BOOL showsZBarControls;
	[Export ("showsZBarControls")]
	bool ShowsZBarControls { get; set; }

	// @property (nonatomic) BOOL tracksSymbols;
	[Export ("tracksSymbols")]
	bool TracksSymbols { get; set; }

	// @property (nonatomic) NSUInteger supportedOrientationsMask;
	[Export ("supportedOrientationsMask")]
	nuint SupportedOrientationsMask { get; set; }

	// @property (nonatomic) CGRect scanCrop;
	[Export ("scanCrop", ArgumentSemantic.Assign)]
	CGRect ScanCrop { get; set; }

	// @property (retain, nonatomic) UIView * cameraOverlayView;
	[Export ("cameraOverlayView", ArgumentSemantic.Retain)]
	UIView CameraOverlayView { get; set; }

	// @property (nonatomic) CGAffineTransform cameraViewTransform;
	[Export ("cameraViewTransform", ArgumentSemantic.Assign)]
	CGAffineTransform CameraViewTransform { get; set; }

	// -(void)showHelpWithReason:(NSString *)reason;
	[Export ("showHelpWithReason:")]
	void ShowHelpWithReason (string reason);

	// -(void)takePicture;
	[Export ("takePicture")]
	void TakePicture ();

	// +(BOOL)isCameraDeviceAvailable:(UIImagePickerControllerCameraDevice)cameraDevice;
	[Static]
	[Export ("isCameraDeviceAvailable:")]
	bool IsCameraDeviceAvailable (UIImagePickerControllerCameraDevice cameraDevice);

	// +(BOOL)isFlashAvailableForCameraDevice:(UIImagePickerControllerCameraDevice)cameraDevice;
	[Static]
	[Export ("isFlashAvailableForCameraDevice:")]
	bool IsFlashAvailableForCameraDevice (UIImagePickerControllerCameraDevice cameraDevice);

	// +(NSArray *)availableCaptureModesForCameraDevice:(UIImagePickerControllerCameraDevice)cameraDevice;
	[Static]
	[Export ("availableCaptureModesForCameraDevice:")]
	[Verify (StronglyTypedNSArray)]
	NSObject[] AvailableCaptureModesForCameraDevice (UIImagePickerControllerCameraDevice cameraDevice);

	// @property (nonatomic) UIImagePickerControllerCameraDevice cameraDevice;
	[Export ("cameraDevice", ArgumentSemantic.Assign)]
	UIImagePickerControllerCameraDevice CameraDevice { get; set; }

	// @property (nonatomic) UIImagePickerControllerCameraFlashMode cameraFlashMode;
	[Export ("cameraFlashMode", ArgumentSemantic.Assign)]
	UIImagePickerControllerCameraFlashMode CameraFlashMode { get; set; }

	// @property (nonatomic) UIImagePickerControllerCameraCaptureMode cameraCaptureMode;
	[Export ("cameraCaptureMode", ArgumentSemantic.Assign)]
	UIImagePickerControllerCameraCaptureMode CameraCaptureMode { get; set; }

	// @property (nonatomic) UIImagePickerControllerQualityType videoQuality;
	[Export ("videoQuality", ArgumentSemantic.Assign)]
	UIImagePickerControllerQualityType VideoQuality { get; set; }

	// @property (readonly, nonatomic) ZBarReaderView * readerView;
	[Export ("readerView")]
	ZBarReaderView ReaderView { get; }

	// @property (nonatomic) BOOL enableCache;
	[Export ("enableCache")]
	bool EnableCache { get; set; }

	// @property (nonatomic) UIImagePickerControllerSourceType sourceType;
	[Export ("sourceType", ArgumentSemantic.Assign)]
	UIImagePickerControllerSourceType SourceType { get; set; }

	// @property (nonatomic) BOOL allowsEditing;
	[Export ("allowsEditing")]
	bool AllowsEditing { get; set; }

	// @property (nonatomic) BOOL allowsImageEditing;
	[Export ("allowsImageEditing")]
	bool AllowsImageEditing { get; set; }

	// @property (nonatomic) BOOL showsCameraControls;
	[Export ("showsCameraControls")]
	bool ShowsCameraControls { get; set; }

	// @property (nonatomic) BOOL showsHelpOnFail;
	[Export ("showsHelpOnFail")]
	bool ShowsHelpOnFail { get; set; }

	// @property (nonatomic) ZBarReaderControllerCameraMode cameraMode;
	[Export ("cameraMode", ArgumentSemantic.Assign)]
	ZBarReaderControllerCameraMode CameraMode { get; set; }

	// @property (nonatomic) BOOL takesPicture;
	[Export ("takesPicture")]
	bool TakesPicture { get; set; }

	// @property (nonatomic) NSInteger maxScanDimension;
	[Export ("maxScanDimension")]
	nint MaxScanDimension { get; set; }

	// +(BOOL)isSourceTypeAvailable:(UIImagePickerControllerSourceType)sourceType;
	[Static]
	[Export ("isSourceTypeAvailable:")]
	bool IsSourceTypeAvailable (UIImagePickerControllerSourceType sourceType);
}
