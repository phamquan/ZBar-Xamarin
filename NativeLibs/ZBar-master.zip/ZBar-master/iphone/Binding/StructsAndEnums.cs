public enum ZBarReaderControllerCameraMode : uint
{
	Default = 0,
	Sampling,
	Sequence
}
